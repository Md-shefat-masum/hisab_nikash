<template>
    <div>
        <router-view></router-view>
    </div>
</template>

<script>
    import { mapGetters, mapActions } from 'vuex';
    export default {
        created: function(){
        },
        methods: {
            // ...mapActions(['fetch_sec_list']),
        },
        computed: {
        },
    }
</script>

<style>

</style>

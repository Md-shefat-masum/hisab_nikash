<?php $__env->startSection('content'); ?>

    <div id="page">

        <?php if(Auth::user()->role_id == 6): ?>
            <?php echo $__env->make('website.layouts.sakha-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <?php if(Auth::user()->role_id == 7): ?>
            <?php echo $__env->make('website.layouts.guest-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <div class="page-content">
            <div class="card card-style shadow-xl content_wraper">
                <div class="content-loader content-loader-hide"></div>
                <div class="content">
                    <?php if(Auth::user()->role_id <= 2): ?>
                        <script>window.location = "/admin";</script>
                    <?php endif; ?>

                    <?php if(Auth::user()->role_id == 6): ?>
                        <sakha></sakha>
                    <?php endif; ?>

                    <?php if(Auth::user()->role_id == 7): ?>
                        <guest></guest>
                    <?php endif; ?>
                </div>
            </div>

            

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('website.layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sobujdiganta/tada.sobujdiganta.com/resources/views/website/index.blade.php ENDPATH**/ ?>
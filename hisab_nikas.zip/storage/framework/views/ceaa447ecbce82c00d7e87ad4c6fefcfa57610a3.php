<div class="logo hm3-logo">
    <a href="/">
        <img src="<?php echo e(asset('contents/website')); ?>/img/logo/1.png" alt="" />
    </a>
</div>
<?php /**PATH D:\xampp\htdocs\Learnig_Project\php learn\laravel_ecommerce\resources\views/website/ecommerce/layouts/logo.blade.php ENDPATH**/ ?>
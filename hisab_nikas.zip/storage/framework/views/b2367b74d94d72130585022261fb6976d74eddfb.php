<ul class="metismenu" id="menu">
    <li>
        <div class="side_bar_top">
            <img src="<?php echo e(asset(''.Auth::user()->photo)); ?>" alt="profile pic">
            <h6><?php echo e(Helper::auth_full_name()); ?></h6>
        </div>
    </li>
    <li>
        <a href="/admin">
            <div class="parent-icon"><i class="fa fa-dashboard"></i></div>
            <div class="menu-title">Dashboard</div>
        </a>
    </li>

    <?php if(Auth::user()->role_id == 1): ?>
        <li>
            <a class="has-arrow" href="#">
                <div class="parent-icon"><i class="zmdi zmdi-view-dashboard"></i></div>
                <div class="menu-title">User Management</div>
            </a>
            <ul class="">
                <li>
                    <a href="<?php echo e(route('admin_user_index')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> index</a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin_user_role_index')); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> User Role</a>
                </li>
            </ul>
        </li>
    <?php endif; ?>



    


    <li class="menu-label">Extra</li>
    <li>
        <a href="/" target="_blank">
            <div class="parent-icon"><i class="fa fa-globe"></i></div>
            <div class="menu-title">Website</div>
        </a>
    </li>
    <li>
        <a  href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault(); confirm('sure!!') && document.getElementById('logout-form').submit();">
            <div class="parent-icon"><i class="fa fa-sign-out"></i></div>
            <div class="menu-title">Logout</div>
        </a>
    </li>

    

</ul>
<?php /**PATH D:\xampp\htdocs\Laravel_Core_Files\default_dashboard\laravel8 dashtreme\resources\views/admin/layouts/includes/sidebar.blade.php ENDPATH**/ ?>
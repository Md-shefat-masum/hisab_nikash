<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <div class="container-fluid">
            <?php echo $__env->make('admin.layouts.includes.bread_cumb',['title'=>'User Management'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <h5 class="card-title">All Users</h5>
                            <a href="<?php echo e(route('admin_user_create')); ?>" class="btn btn-warning waves-effect waves-light m-1">
                                <i class="fa fa-plus"></i> <span>Add New</span>
                            </a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">first name</th>
                                            <th scope="col">last name</th>
                                            <th scope="col">username</th>
                                            <th scope="col">email</th>
                                            <th scope="col">role name</th>
                                            <th scope="col">created at</th>
                                            <th scope="col">Action</th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row">1</th>
                                                <td><?php echo e($item->first_name); ?></td>
                                                <td><?php echo e($item->last_name); ?></td>
                                                <td><?php echo e($item->username); ?></td>
                                                <td><?php echo e($item->email); ?></td>
                                                
                                                <td><?php echo e($item->role_information ? $item->role_information->name : $item->role_id); ?></td>
                                                <td><?php echo e($item->created_at->format('d M Y h:i:s a')); ?></td>
                                                <td>
                                                    <div>
                                                        <a type="button" href="<?php echo e(route('admin_user_view',$item->id)); ?>" class="btn btn-light waves-effect waves-light m-1">
                                                            <i class="fa fa-eye"></i> <span>view</span>
                                                        </a>
                                                        <a type="button" href="<?php echo e(route('admin_user_edit',$item->id)); ?>" class="btn btn-warning waves-effect waves-light m-1">
                                                            <i class="fa fa-pencil"></i> <span>edit</span>
                                                        </a>
                                                        
                                                        <a type="button" href="#"
                                                            onclick="return (confirm('hei, Do you sure want to delete.') && $.post('<?php echo e(route('admin_user_delete',['id'=>$item->id])); ?>',(res)=>{console.log(res,$(this).parents('tr').remove())}))"
                                                            class=" btn btn-danger waves-effect waves-light m-1">
                                                            <i class="fa fa-trash-o"></i> <span>delete</span>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--start overlay-->
            <div class="overlay"></div>
            <!--end overlay-->
        </div>
        <!-- End container-fluid-->
    </div>
    <!--End content-wrapper-->

<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Core_Files\default_dashboard\laravel8 dashtreme\resources\views/admin/user/index.blade.php ENDPATH**/ ?>
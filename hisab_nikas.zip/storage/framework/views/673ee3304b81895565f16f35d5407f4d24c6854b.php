<?php $__env->startSection('content'); ?>

    <div id="page">

        <?php if(Auth::user()->role_id == 4): ?>
            <?php echo $__env->make('website.layouts.employee-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <?php if(Auth::user()->role_id == 2): ?>
            <?php echo $__env->make('website.layouts.admin-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <div class="page-content">
            <div class="card card-style shadow-xl content_wraper">
                <div class="content-loader content-loader-hide"></div>
                <div class="content">
                    

                    <?php if(Auth::user()->role_id == 4): ?>
                        <employee></employee>
                    <?php endif; ?>

                    <?php if(Auth::user()->role_id == 2): ?>
                        <admin></admin>
                    <?php endif; ?>
                </div>
            </div>

            

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('website.layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Hsblco\hisab_nikas\resources\views/website/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <div class="container-fluid">
            <?php echo $__env->make('admin.layouts.includes.bread_cumb',['title'=>'All'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <h5 class="card-title">Program Types</h5>
                            <a href="<?php echo e(route('program-type.create')); ?>" class="btn btn-success">Create</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = App\Models\ProgramType::orderBy('id','DESC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($key+1); ?></th>
                                                <td><?php echo e($item->name); ?></td>
                                                <td>
                                                    <div>
                                                        <a type="button" href="<?php echo e(route('program-type.edit',$item->id)); ?>" class="btn btn-light waves-effect waves-light m-1">
                                                            <i class="fa fa-pencil"></i> <span>Edit</span>
                                                        </a>
                                                        <a type="button" href="<?php echo e(route('program-type.destroy',$item->id)); ?>" class="btn delete_btn btn-danger waves-effect waves-light m-1">
                                                            <i class="fa fa-trash"></i> <span>delete</span>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--start overlay-->
            <div class="overlay"></div>
            <!--end overlay-->
        </div>
        <!-- End container-fluid-->
    </div>
    <!--End content-wrapper-->

<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Earth_Face_Projects\tada\resources\views/admin/program_type/index.blade.php ENDPATH**/ ?>
<ul class="fm_image_list">
    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <div class="image_body">
                <input type="checkbox" data-name="<?php echo e($item->name); ?>" value="<?php echo e($item->id); ?>" class="form-control fm_checkbox">
                <div class="controls">
                    <i class="icon-options-vertical icons"></i>
                    <ul>
                        <li><a href="#"><i class="icon-magnifier icons"></i> View</a></li>
                        <li><a href="<?php echo e(route('admin_fm_delete_file',$item->id)); ?>" class="delete_btn"><i class="icon-trash icons"></i> Delete</a></li>
                    </ul>
                </div>
                <img src="/<?php echo e($item->name); ?>" alt="product image">
            </div>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH D:\xampp\htdocs\Learnig_Project\php learn\laravel_ecommerce\resources\views/admin/product/components/file_manager_image_body.blade.php ENDPATH**/ ?>
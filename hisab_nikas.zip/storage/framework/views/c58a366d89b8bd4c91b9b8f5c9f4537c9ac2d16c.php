<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <div class="container-fluid">
            <?php echo $__env->make('admin.layouts.includes.bread_cumb',['title'=>'All'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Earning List</h5>
                            <div class="table-responsive">
                                <table class="table" id="example">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Guest</th>
                                            <th scope="col">Sakha</th>
                                            <th scope="col">Total</th>
                                            <th scope="col">created at</th>
                                            <th scope="col">Approve</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = App\Models\SakhaExpense::where('approved',0)->orderBy('id','DESC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row">1</th>
                                                <td><?php echo e($item->guest->username); ?></td>
                                                <td><?php echo e($item->sakha->username); ?></td>
                                                <td><?php echo e($item->amount); ?></td>
                                                <td><?php echo e($item->created_at->format('d-M-Y j:i:s a')); ?></td>
                                                <td>
                                                    <div>
                                                        <a onclick="return confirm('sure want to approve')" type="button" href="<?php echo e(route('admin_approve_voucher',$item->id)); ?>"
                                                            class="btn btnPrint btn-light waves-effect waves-light m-1">
                                                            <i class="fa fa-plus-square"></i> <span>Accept</span>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--start overlay-->
            <div class="overlay"></div>
            <!--end overlay-->
        </div>
        <!-- End container-fluid-->
    </div>
    <!--End content-wrapper-->

    <?php $__env->startPush('jsplugin'); ?>
        <!--Data Tables js-->
        <script src="/contents/admin/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
        <script src="/contents/admin/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
        <script src="/contents/admin/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
        <script src="/contents/admin/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
        <script src="/contents/admin/plugins/bootstrap-datatable/js/jszip.min.js"></script>
        <script src="/contents/admin/plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
        <script src="/contents/admin/plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
        <script src="/contents/admin/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
        <script src="/contents/admin/plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
        <script src="/contents/admin/plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('cjs'); ?>
        <script>
            $(document).ready(function() {

                var table = $('#example').DataTable( {
                    lengthChange: false,
                    buttons: [ 'copy', 'excel', 'pdf', 'print', 'colvis' ]
                } );

                table.buttons().container()
                    .appendTo( '#example_wrapper .col-md-6:eq(0)' );
                } );

       </script>
       <style>
            #example_filter{
                text-align: right;
            }
            .card .table {
                margin-bottom: 63px;
            }
            .pagination{
                display: inline-flex;
            }
            .dataTables_paginate{
                text-align: right;
            }
       </style>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Earth_Face_Projects\tada\resources\views/admin/expense/pending_list.blade.php ENDPATH**/ ?>
<!-- Breadcrumb-->
<div class="row pt-2 pb-2">
    <div class="col-sm-9">
        <h4 class="page-title"><?php echo e($title); ?></h4>
        <ol class="breadcrumb">
            <?php
                $path_info = $_SERVER['PATH_INFO'];
                $path_info = explode('/',$path_info);
            ?>
            <?php $__currentLoopData = $path_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="breadcrumb-item">
                    <a href="javaScript:void();"><?php echo e($item); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
    </div>
</div>
<!-- End Breadcrumb-->
<?php /**PATH D:\xampp\htdocs\Laravel_Core_Files\default_dashboard\laravel8 dashtreme\resources\views/admin/includes/bread_cumb.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <style>
        .card .table td, .card .table th {
            white-space: break-spaces;
        }
    </style>
    <div class="content-wrapper">
        <div class="container-fluid">
            <?php echo $__env->make('admin.includes.bread_cumb',['title'=>'View'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-bordered table-hover table-striped">
                                <tr>
                                    <td style="width: 40%">Photo</td>
                                    <td>:</td>
                                    <td>
                                        <img src="/<?php echo e($user->photo); ?>" height="60" alt="" srcset="">
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">First Name</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($user->first_name); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Last Name</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($user->last_name); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">User Name</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($user->username); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Email</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($user->email); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Role Name</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($user->role_id); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Created at</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($user->created_at); ?>

                                    </td>
                                </tr>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--start overlay-->
            <div class="overlay"></div>
            <!--end overlay-->
        </div>
        <!-- End container-fluid-->
    </div>
    <!--End content-wrapper-->

<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Learnig_Project\php learn\laravel_ecommerce\resources\views/admin/user/view.blade.php ENDPATH**/ ?>